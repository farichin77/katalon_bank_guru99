<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_window.dataLayer  window.dataLayer    _1692b1</name>
   <tag></tag>
   <elementGuidId>4dad64a4-abda-4462-a3ea-976d82ecccf3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>body</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>53f4e490-786c-40d8-8af5-2d03ff9dc29d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    







  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-JLJFWVDS10');



    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src=&quot;https://www.clarity.ms/tag/&quot;+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, &quot;clarity&quot;, &quot;script&quot;, &quot;p5hgnh28p2&quot;);


 
        
        
            
                
                      
                    Demo Site
                    
                   
                
                
                    
                        
                        
                        
                    
                    
                
            
            
               
 
            
                
            
        

        // Array of image objects with URL and optional link
        const images1 = [
            { src: 'https://demo.guru99.com/images/zoho-bug-tracking.png', link: 'https://guru99.link/recommends-zoho-projects-bugtracking-tool' },
            { src: 'https://demo.guru99.com/images/jira-software-top-ads.png', link: 'https://guru99.live/4ljs1t' }
        ];

        // Pick a random image
        const randomImage1 = images1[Math.floor(Math.random() * images1.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container1 = document.querySelector('.image-container1');

        // Insert the clickable image into the container
        container1.innerHTML = `
            &lt;a href=&quot;${randomImage1.link}&quot; target=&quot;_blank&quot; onclick=&quot;gtag('event', 'find_someones_social_media_accounts', { 'event_category': 'Demo Guru99', 'event_action':'Click','event_label':'Demo Guru99' });&quot;>
                &lt;p>&lt;img src=&quot;${randomImage1.src}&quot; alt=&quot;JIRA Top ADS&quot; style=&quot;width:50%&quot;>
            &lt;/a>
        `;


             

            
        
        
        
   

            
                
                    
                   

                    
                    
                        
                            
                                Selenium
					  
                                
                                    Flash Movie Demo
                                    Radio &amp; Checkbox Demo 
                                    Table Demo 
                                    Accessing Link
                                    Ajax Demo
                                    Inside &amp; Outside Block Level Tag
                                    Delete Customer Form
                                    Yahoo
                                    Tooltip
                                    File Upload
                                    Login
                                    Social Icon
                                    Selenium Auto IT
                                    Selenium IDE Test
                                    Guru99 Demo Page
                                    Scrollbar Demo
                                    File Upload using Sikuli Demo
                                    Cookie Handling Demo
                                    Drag and Drop Action
                                    Selenium DatePicker Demo
                                
                            
                            
                                                                                                                                          
                             
                             
                                 Insurance Project                             
                             
                               Agile Project
                                
                            
                             
                                                                                                  
                                    
                                 Bank ProjectBank Project V1Bank Project V2Bank Project V3        
                            
                            Security Project                            
                             
                                                       
                           Telecom Project
                           
                           Payment Gateway Project
                           
                           New Tours
                           
                           
                                SEO
					            
                                
                                   Page-1
                                   Page-2
                                   Page-3
                                   Page-4
                                   Page-5
                                   Page-6
                                
                            
                        
                       
                        
                    
                    
                
                
            
        
     
     
   Guru99 Bank
   
   
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out



   
  
	
	  
		
		  
			
			Add new account form
			
			
			
			Customer id
			 Account type
			
			Savings
			Current
			
			
			
			
                            Initial deposit
			
			
			
			
			
			
		
		
	
	

Home


© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: 'https://demo.guru99.com/images/zoho-project-v1.png', link: 'https://guru99.link/recommends-zoho-project-jira-alternative' },
            { src: 'https://demo.guru99.com/images/zoho-demoguru99.png', link: 'https://guru99.live/umr9yl' }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector('.image-container');

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
     




</value>
      <webElementGuid>7a91efc0-5658-497d-92b6-fd40b5293d82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]</value>
      <webElementGuid>7504175c-6a13-4a98-8609-32c847869aed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>6869d383-489d-44f9-84ea-d5b6b76c9052</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;
    
    







  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(&quot; , &quot;'&quot; , &quot;js&quot; , &quot;'&quot; , &quot;, new Date());

  gtag(&quot; , &quot;'&quot; , &quot;config&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;G-JLJFWVDS10&quot; , &quot;'&quot; , &quot;);



    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src=&quot;https://www.clarity.ms/tag/&quot;+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, &quot;clarity&quot;, &quot;script&quot;, &quot;p5hgnh28p2&quot;);


 
        
        
            
                
                      
                    Demo Site
                    
                   
                
                
                    
                        
                        
                        
                    
                    
                
            
            
               
 
            
                
            
        

        // Array of image objects with URL and optional link
        const images1 = [
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-bug-tracking.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-projects-bugtracking-tool&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/jira-software-top-ads.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/4ljs1t&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage1 = images1[Math.floor(Math.random() * images1.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container1 = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container1&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container1.innerHTML = `
            &lt;a href=&quot;${randomImage1.link}&quot; target=&quot;_blank&quot; onclick=&quot;gtag(&quot; , &quot;'&quot; , &quot;event&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;find_someones_social_media_accounts&quot; , &quot;'&quot; , &quot;, { &quot; , &quot;'&quot; , &quot;event_category&quot; , &quot;'&quot; , &quot;: &quot; , &quot;'&quot; , &quot;Demo Guru99&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;event_action&quot; , &quot;'&quot; , &quot;:&quot; , &quot;'&quot; , &quot;Click&quot; , &quot;'&quot; , &quot;,&quot; , &quot;'&quot; , &quot;event_label&quot; , &quot;'&quot; , &quot;:&quot; , &quot;'&quot; , &quot;Demo Guru99&quot; , &quot;'&quot; , &quot; });&quot;>
                &lt;p>&lt;img src=&quot;${randomImage1.src}&quot; alt=&quot;JIRA Top ADS&quot; style=&quot;width:50%&quot;>
            &lt;/a>
        `;


             

            
        
        
        
   

            
                
                    
                   

                    
                    
                        
                            
                                Selenium
					  
                                
                                    Flash Movie Demo
                                    Radio &amp; Checkbox Demo 
                                    Table Demo 
                                    Accessing Link
                                    Ajax Demo
                                    Inside &amp; Outside Block Level Tag
                                    Delete Customer Form
                                    Yahoo
                                    Tooltip
                                    File Upload
                                    Login
                                    Social Icon
                                    Selenium Auto IT
                                    Selenium IDE Test
                                    Guru99 Demo Page
                                    Scrollbar Demo
                                    File Upload using Sikuli Demo
                                    Cookie Handling Demo
                                    Drag and Drop Action
                                    Selenium DatePicker Demo
                                
                            
                            
                                                                                                                                          
                             
                             
                                 Insurance Project                             
                             
                               Agile Project
                                
                            
                             
                                                                                                  
                                    
                                 Bank ProjectBank Project V1Bank Project V2Bank Project V3        
                            
                            Security Project                            
                             
                                                       
                           Telecom Project
                           
                           Payment Gateway Project
                           
                           New Tours
                           
                           
                                SEO
					            
                                
                                   Page-1
                                   Page-2
                                   Page-3
                                   Page-4
                                   Page-5
                                   Page-6
                                
                            
                        
                       
                        
                    
                    
                
                
            
        
     
     
   Guru99 Bank
   
   
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out



   
  
	
	  
		
		  
			
			Add new account form
			
			
			
			Customer id
			 Account type
			
			Savings
			Current
			
			
			
			
                            Initial deposit
			
			
			
			
			
			
		
		
	
	

Home


© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-project-v1.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-project-jira-alternative&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-demoguru99.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/umr9yl&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
     




&quot;) or . = concat(&quot;
    
    







  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(&quot; , &quot;'&quot; , &quot;js&quot; , &quot;'&quot; , &quot;, new Date());

  gtag(&quot; , &quot;'&quot; , &quot;config&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;G-JLJFWVDS10&quot; , &quot;'&quot; , &quot;);



    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src=&quot;https://www.clarity.ms/tag/&quot;+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, &quot;clarity&quot;, &quot;script&quot;, &quot;p5hgnh28p2&quot;);


 
        
        
            
                
                      
                    Demo Site
                    
                   
                
                
                    
                        
                        
                        
                    
                    
                
            
            
               
 
            
                
            
        

        // Array of image objects with URL and optional link
        const images1 = [
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-bug-tracking.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-projects-bugtracking-tool&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/jira-software-top-ads.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/4ljs1t&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage1 = images1[Math.floor(Math.random() * images1.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container1 = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container1&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container1.innerHTML = `
            &lt;a href=&quot;${randomImage1.link}&quot; target=&quot;_blank&quot; onclick=&quot;gtag(&quot; , &quot;'&quot; , &quot;event&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;find_someones_social_media_accounts&quot; , &quot;'&quot; , &quot;, { &quot; , &quot;'&quot; , &quot;event_category&quot; , &quot;'&quot; , &quot;: &quot; , &quot;'&quot; , &quot;Demo Guru99&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;event_action&quot; , &quot;'&quot; , &quot;:&quot; , &quot;'&quot; , &quot;Click&quot; , &quot;'&quot; , &quot;,&quot; , &quot;'&quot; , &quot;event_label&quot; , &quot;'&quot; , &quot;:&quot; , &quot;'&quot; , &quot;Demo Guru99&quot; , &quot;'&quot; , &quot; });&quot;>
                &lt;p>&lt;img src=&quot;${randomImage1.src}&quot; alt=&quot;JIRA Top ADS&quot; style=&quot;width:50%&quot;>
            &lt;/a>
        `;


             

            
        
        
        
   

            
                
                    
                   

                    
                    
                        
                            
                                Selenium
					  
                                
                                    Flash Movie Demo
                                    Radio &amp; Checkbox Demo 
                                    Table Demo 
                                    Accessing Link
                                    Ajax Demo
                                    Inside &amp; Outside Block Level Tag
                                    Delete Customer Form
                                    Yahoo
                                    Tooltip
                                    File Upload
                                    Login
                                    Social Icon
                                    Selenium Auto IT
                                    Selenium IDE Test
                                    Guru99 Demo Page
                                    Scrollbar Demo
                                    File Upload using Sikuli Demo
                                    Cookie Handling Demo
                                    Drag and Drop Action
                                    Selenium DatePicker Demo
                                
                            
                            
                                                                                                                                          
                             
                             
                                 Insurance Project                             
                             
                               Agile Project
                                
                            
                             
                                                                                                  
                                    
                                 Bank ProjectBank Project V1Bank Project V2Bank Project V3        
                            
                            Security Project                            
                             
                                                       
                           Telecom Project
                           
                           Payment Gateway Project
                           
                           New Tours
                           
                           
                                SEO
					            
                                
                                   Page-1
                                   Page-2
                                   Page-3
                                   Page-4
                                   Page-5
                                   Page-6
                                
                            
                        
                       
                        
                    
                    
                
                
            
        
     
     
   Guru99 Bank
   
   
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out



   
  
	
	  
		
		  
			
			Add new account form
			
			
			
			Customer id
			 Account type
			
			Savings
			Current
			
			
			
			
                            Initial deposit
			
			
			
			
			
			
		
		
	
	

Home


© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-project-v1.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-project-jira-alternative&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-demoguru99.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/umr9yl&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
     




&quot;))]</value>
      <webElementGuid>f2e568cb-9dfa-4ead-a8e2-b2d97bb24e9d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
