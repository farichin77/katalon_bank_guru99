<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_ManagerNew CustomerEdit CustomerDelete _5fc5d3</name>
   <tag></tag>
   <elementGuidId>9cb2191f-a0e6-462c-9a70-50cd659fa304</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(3) > div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Guru99 Bank'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Manager New Customer Edit Customer Delete Customer New Account Edit Account Dele&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>985abddd-5b8b-41d3-8e5b-e5872e217ee1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
</value>
      <webElementGuid>05708710-3791-46df-8f38-c89bb67f9ab8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]</value>
      <webElementGuid>1de0036a-88bd-4fa1-952f-e29c4172ddcd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guru99 Bank'])[1]/following::div[2]</value>
      <webElementGuid>ee48cc0f-d979-4fd0-91c6-2b1c56b161db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Page-6'])[1]/following::div[3]</value>
      <webElementGuid>e26a6b33-c26e-4b86-9f45-1f1cf99b5f36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>e087a541-43d7-4a86-90a5-420f923fbbec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
' or . = '
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
')]</value>
      <webElementGuid>5625710d-a5a0-49b8-8b9d-0b9870ed43e3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
