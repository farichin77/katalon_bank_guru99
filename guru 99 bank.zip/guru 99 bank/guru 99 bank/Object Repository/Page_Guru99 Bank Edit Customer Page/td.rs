<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td</name>
   <tag></tag>
   <elementGuidId>cf955af3-43c2-412f-890a-cc14c89c10ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer ID is required'])[1]/following::td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(11) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Submit Reset&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>ec338fc2-32d2-4775-91a5-eff6adfc10dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[2]/table[@class=&quot;layout&quot;]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[11]/td[2]</value>
      <webElementGuid>45d0ec3c-f077-402c-8a21-4f2a43babd86</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer ID is required'])[1]/following::td[2]</value>
      <webElementGuid>6caaeb56-47a1-430d-9da9-9157a181bf89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer ID'])[1]/following::td[3]</value>
      <webElementGuid>ca639d20-b3d0-471d-8a08-eef779258b40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/preceding::td[1]</value>
      <webElementGuid>70e61585-6cc4-4f1b-a718-fc3c04814122</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='© Copyright - Demo Guru99 2025'])[1]/preceding::td[1]</value>
      <webElementGuid>3c3ae854-62eb-4e02-b949-5e38758e3322</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[11]/td[2]</value>
      <webElementGuid>c17de812-4c4f-4aa5-a481-bbe4d7fbd285</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
