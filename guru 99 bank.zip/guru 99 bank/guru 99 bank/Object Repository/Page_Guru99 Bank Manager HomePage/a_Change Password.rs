<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Change Password</name>
   <tag></tag>
   <elementGuidId>f180b8cb-4291-44f3-92c0-122822dfed8f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.menusubnav > li:nth-of-type(11) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Change Password')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Change Password&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cef50db3-1867-481a-bb6a-2b3dd1cbc208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>PasswordInput.php</value>
      <webElementGuid>1e9b8699-85b2-4652-af33-bc7af6743957</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Change Password</value>
      <webElementGuid>e8ab2fd0-ac68-4d89-a207-65de67df7bb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]/ul[@class=&quot;menusubnav&quot;]/li[11]/a[1]</value>
      <webElementGuid>92102bed-b6c1-40e8-9079-69e207a79010</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Change Password')]</value>
      <webElementGuid>da938987-2821-408d-85b0-600c53094bd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fund Transfer'])[1]/following::a[1]</value>
      <webElementGuid>821432db-15f2-486e-802e-f8b5a761810a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Withdrawal'])[1]/following::a[2]</value>
      <webElementGuid>85369ed5-b4df-408e-9101-a2d4a6793d41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Balance Enquiry'])[1]/preceding::a[1]</value>
      <webElementGuid>61a4d11a-1265-4b55-aaf2-ddb838e36dea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mini Statement'])[1]/preceding::a[2]</value>
      <webElementGuid>9f38ecf8-f6cf-4ec6-a9bb-c4658b9c03ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Change Password']/parent::*</value>
      <webElementGuid>5afe0c5f-6c41-4a02-8ba3-88594b514a70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'PasswordInput.php')]</value>
      <webElementGuid>ac4cbbab-a501-4ffa-91a4-c70e65c4919e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/ul/li[11]/a</value>
      <webElementGuid>552627bc-6cc5-4b23-b87c-6208b167824b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'PasswordInput.php' and (text() = 'Change Password' or . = 'Change Password')]</value>
      <webElementGuid>bb53be69-622c-4732-bdef-b8f1a04ca373</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
