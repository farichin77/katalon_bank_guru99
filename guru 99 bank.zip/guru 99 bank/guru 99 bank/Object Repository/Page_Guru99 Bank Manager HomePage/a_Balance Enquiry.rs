<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Balance Enquiry</name>
   <tag></tag>
   <elementGuidId>861b93c6-8124-4b3d-9a02-667d50f480d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.menusubnav > li:nth-of-type(12) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Balance Enquiry')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Balance Enquiry&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7f66842d-eb62-40bb-ba08-53eddafbb6b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>BalEnqInput.php</value>
      <webElementGuid>15dc54bd-8cfe-4235-b7ee-bb71a631457b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Balance Enquiry</value>
      <webElementGuid>4c636d25-1c9f-45e1-9964-bc32f3bf852c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]/ul[@class=&quot;menusubnav&quot;]/li[12]/a[1]</value>
      <webElementGuid>0cbbe30b-2962-4079-a4ef-82b6a2dc516f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Balance Enquiry')]</value>
      <webElementGuid>255b9289-c20a-4b9c-a718-3d93f0b26e64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[1]/following::a[1]</value>
      <webElementGuid>9edaa559-64b4-4dbc-8a5d-a1e8a31c8da8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fund Transfer'])[1]/following::a[2]</value>
      <webElementGuid>25e3f6c6-7586-4db0-9653-d4ae1a92e954</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mini Statement'])[1]/preceding::a[1]</value>
      <webElementGuid>82561e85-c24d-42ca-9d9e-9fdf45267bd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customised Statement'])[1]/preceding::a[2]</value>
      <webElementGuid>68025c30-94eb-4296-990a-de44b5944e3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Balance Enquiry']/parent::*</value>
      <webElementGuid>dda98814-d607-4025-b757-01cf0160eb86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'BalEnqInput.php')]</value>
      <webElementGuid>daa226c9-423c-4ee1-9a16-88726abfaf04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[12]/a</value>
      <webElementGuid>84a422c7-9428-4b17-8a2d-86ebdfee3ed4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'BalEnqInput.php' and (text() = 'Balance Enquiry' or . = 'Balance Enquiry')]</value>
      <webElementGuid>c088128f-3691-42a9-8c1e-33a0663b370b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
