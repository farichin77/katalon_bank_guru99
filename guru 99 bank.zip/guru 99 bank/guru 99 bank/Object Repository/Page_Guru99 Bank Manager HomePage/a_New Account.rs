<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_New Account</name>
   <tag></tag>
   <elementGuidId>4bd77427-e06e-4df7-8a95-389a93ccbcd9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.menusubnav > li:nth-of-type(5) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'New Account')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;New Account&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7d552be2-5bcd-4d19-9ff0-debb2b0e10e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>addAccount.php</value>
      <webElementGuid>6d6b89d6-3e96-494c-8825-1a54a6f88d94</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Account</value>
      <webElementGuid>0a4e2af5-8597-40e2-8ee8-6d8d0e22bcf6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]/ul[@class=&quot;menusubnav&quot;]/li[5]/a[1]</value>
      <webElementGuid>2753357a-c924-45dd-984c-fe7e1ab2761f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'New Account')]</value>
      <webElementGuid>29c7f640-8211-402d-a583-07ba15865ecd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete Customer'])[1]/following::a[1]</value>
      <webElementGuid>c10ae759-3e2e-472c-9606-5fd6ce48b654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Customer'])[1]/following::a[2]</value>
      <webElementGuid>c2566bda-e802-417e-bb01-5ca9d22c52b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Account'])[1]/preceding::a[1]</value>
      <webElementGuid>9e74c830-f744-4d98-bc59-e172f22d90e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete Account'])[1]/preceding::a[2]</value>
      <webElementGuid>7c6a9f42-0724-4547-94e2-2705459e0798</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Account']/parent::*</value>
      <webElementGuid>4d24e958-761b-4faf-9d0c-a8e3b4633a26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'addAccount.php')]</value>
      <webElementGuid>0a485195-4d2b-4439-8d43-5be6b48f33d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/ul/li[5]/a</value>
      <webElementGuid>9ee1108c-768c-468c-a275-634ef0a3f4e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'addAccount.php' and (text() = 'New Account' or . = 'New Account')]</value>
      <webElementGuid>7ab6ea0d-777f-4092-a16d-36821a9c8a7d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
