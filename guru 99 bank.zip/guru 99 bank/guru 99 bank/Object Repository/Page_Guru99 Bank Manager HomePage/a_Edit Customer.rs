<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Edit Customer</name>
   <tag></tag>
   <elementGuidId>1137a465-53a8-4ed4-a9de-dd46cadf0a70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Edit Customer')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.menusubnav > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Edit Customer&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d06cf516-f9a8-4722-ab5b-a6e9180bca2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>EditCustomer.php</value>
      <webElementGuid>7c51395a-3fcd-4558-9bed-20cd7d357301</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit Customer</value>
      <webElementGuid>331c3097-3c21-4da1-a212-defa9390d4b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]/ul[@class=&quot;menusubnav&quot;]/li[3]/a[1]</value>
      <webElementGuid>276d5f66-7011-47d4-948e-7b98d2340899</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Edit Customer')]</value>
      <webElementGuid>4eb7fb84-c725-48ba-bb2d-d9c708d5374a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Customer'])[1]/following::a[1]</value>
      <webElementGuid>54ae496b-7eb8-49fe-a430-08c1203d2299</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manager'])[1]/following::a[2]</value>
      <webElementGuid>ae88ab82-79c7-4855-921e-3d56c000e015</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete Customer'])[1]/preceding::a[1]</value>
      <webElementGuid>06adfc79-716d-4e03-bb8f-23483ab0c7b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Account'])[1]/preceding::a[2]</value>
      <webElementGuid>7ed2aa8b-01c9-4084-82d5-b5173f457f2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Edit Customer']/parent::*</value>
      <webElementGuid>2f08a810-cbb0-49f6-b640-2635d93a5e4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'EditCustomer.php')]</value>
      <webElementGuid>d1f5a96b-8fc8-4672-bfe7-256ede25c446</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/ul/li[3]/a</value>
      <webElementGuid>054ea0d9-243b-483a-bbfa-3f29824a8ad6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'EditCustomer.php' and (text() = 'Edit Customer' or . = 'Edit Customer')]</value>
      <webElementGuid>8aaa996a-0b8f-40de-aa39-8582fd86f41f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
