<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_ManagerNew CustomerEdit CustomerDelete _5fc5d3</name>
   <tag></tag>
   <elementGuidId>0b5323ac-1601-4a2f-a519-626608cbd162</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Guru99 Bank'])[1]/following::div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div:nth-of-type(3) > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Manager New Customer Edit Customer Delete Customer New Account Edit Account Dele&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>89b438a1-6f9e-4451-8430-dffe4abbe226</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
</value>
      <webElementGuid>42ce18b5-1beb-4c7a-8c1c-5b03a9a712b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]</value>
      <webElementGuid>0f36c68f-327b-41b2-af4b-6440f7a28605</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guru99 Bank'])[1]/following::div[2]</value>
      <webElementGuid>edc44737-2016-42c7-a80d-3d1421c94ca9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Page-6'])[1]/following::div[3]</value>
      <webElementGuid>54e8dd8f-f5b2-4334-965d-af725ce96ab8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>ea3e9381-7d65-4cac-ac2d-021922d78821</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
' or . = '
Manager
New Customer
Edit Customer
Delete Customer
New Account
Edit Account
Delete Account
Deposit
Withdrawal
Fund Transfer
Change Password
Balance Enquiry
Mini Statement
Customised Statement
Log out
')]</value>
      <webElementGuid>b67ea6ae-257f-46ef-b8fe-a96d8948dfce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
