<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Edit CustomerCustomer Name        Gender_cee98d</name>
   <tag></tag>
   <elementGuidId>2997d19a-c44e-48bc-8570-aa4a3e7c2db0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::td[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Edit Customer Customer Name Gender Date of Birth Address City State PIN Mobile Number E-mail Submit Reset Home © Copyright - Demo Guru99 2025 Random Image&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>547cddc3-938b-470d-9db3-024f6a1bf5f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>colspan</name>
      <type>Main</type>
      <value>2</value>
      <webElementGuid>69f15726-da93-4e40-99b3-03ac561c3289</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

	



	Edit Customer










	Customer Name
        






	Gender
	





		Date of Birth
		





	Address
	
		jalan cemara
                
	



	City
        




	State
        




	PIN
        





	Mobile Number
        





	E-mail
        





    
		
		





Home



© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: 'https://demo.guru99.com/images/zoho-project-v1.png', link: 'https://guru99.link/recommends-zoho-project-jira-alternative' },
            { src: 'https://demo.guru99.com/images/zoho-demoguru99.png', link: 'https://guru99.live/umr9yl' }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector('.image-container');

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
      


</value>
      <webElementGuid>9b16a148-23bc-4f21-947a-d962b1b8c47d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/table[@class=&quot;layout&quot;]/tbody[1]/tr[1]/td[1]</value>
      <webElementGuid>d8ab8f76-38ac-472b-a4a9-158b6e9198b3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::td[1]</value>
      <webElementGuid>504a5a01-84ed-46e6-84ba-29d8e0b7f38b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customised Statement'])[1]/following::td[1]</value>
      <webElementGuid>0abea92b-d84e-460f-b6b4-eb8262d89ff5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td</value>
      <webElementGuid>c600e7ca-2c76-4fbf-b864-36521179b1cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = concat(&quot;

	



	Edit Customer










	Customer Name
        






	Gender
	





		Date of Birth
		





	Address
	
		jalan cemara
                
	



	City
        




	State
        




	PIN
        





	Mobile Number
        





	E-mail
        





    
		
		





Home



© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-project-v1.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-project-jira-alternative&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-demoguru99.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/umr9yl&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
      


&quot;) or . = concat(&quot;

	



	Edit Customer










	Customer Name
        






	Gender
	





		Date of Birth
		





	Address
	
		jalan cemara
                
	



	City
        




	State
        




	PIN
        





	Mobile Number
        





	E-mail
        





    
		
		





Home



© Copyright - Demo Guru99 2025         


            
                
            
        

        // Array of image objects with URL and optional link
        const images = [
            
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-project-v1.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.link/recommends-zoho-project-jira-alternative&quot; , &quot;'&quot; , &quot; },
            { src: &quot; , &quot;'&quot; , &quot;https://demo.guru99.com/images/zoho-demoguru99.png&quot; , &quot;'&quot; , &quot;, link: &quot; , &quot;'&quot; , &quot;https://guru99.live/umr9yl&quot; , &quot;'&quot; , &quot; }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class &quot;image-container&quot;
        const container = document.querySelector(&quot; , &quot;'&quot; , &quot;.image-container&quot; , &quot;'&quot; , &quot;);

        // Insert the clickable image into the container
        container.innerHTML = `
            &lt;a href=&quot;${randomImage.link}&quot; target=&quot;_blank&quot;>
                &lt;p style=&quot;text-align:center;&quot;>&lt;img src=&quot;${randomImage.src}&quot; alt=&quot;Random Image&quot;>
            &lt;/a>
        `;


!function(e,t){(e=t.createElement(&quot;script&quot;)).src=&quot;https://cdn.convertbox.com/convertbox/js/embed.js&quot;,e.id=&quot;app-convertbox-script&quot;,e.async=true,e.dataset.uuid=&quot;d2df1cad-c542-4d25-b3a2-11e71e75a285&quot;,document.getElementsByTagName(&quot;head&quot;)[0].appendChild(e)}(window,document);  


    
    
    
      


&quot;))]</value>
      <webElementGuid>6b100786-90b8-42bd-a8f1-252df91243cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
