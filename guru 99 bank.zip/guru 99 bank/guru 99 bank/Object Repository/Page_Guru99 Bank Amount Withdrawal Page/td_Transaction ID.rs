<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Transaction ID</name>
   <tag></tag>
   <elementGuidId>9d6d9263-9389-4c38-991b-5b13a98be7c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(6) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='withdraw']/tbody/tr[6]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Transaction ID&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>79135007-c4d7-4f4e-b8d3-ae6fcfd8bd6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Transaction ID</value>
      <webElementGuid>5b17cd71-ab44-4896-8667-f6663a701d51</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;withdraw&quot;)/tbody[1]/tr[6]/td[1]</value>
      <webElementGuid>21c10847-c8da-4969-87dd-bdbf9c26730a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='withdraw']/tbody/tr[6]/td</value>
      <webElementGuid>f5f8db5e-3c15-4c9a-bab2-c3925365ff75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log out'])[1]/following::td[3]</value>
      <webElementGuid>96eac23f-6299-4ca0-a780-4294bb07abef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customised Statement'])[1]/following::td[3]</value>
      <webElementGuid>b9017b0c-4132-4a43-9a67-1fe89539f793</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Transaction ID']/parent::*</value>
      <webElementGuid>ec3149a4-ba92-4153-8850-b114fd9a8c2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[6]/td</value>
      <webElementGuid>316198fb-d383-440e-8c2e-0cc0d71aa1e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Transaction ID' or . = 'Transaction ID')]</value>
      <webElementGuid>81617892-01e4-4fd5-b196-339bdc4538cd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
