<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_New Customer</name>
   <tag></tag>
   <elementGuidId>45ea947e-6636-47a5-965d-630f4650996e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.menusubnav > li:nth-of-type(2) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'New Customer')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;New Customer&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a89e8c6d-2b19-4286-8b35-38faece65f30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>addcustomerpage.php</value>
      <webElementGuid>c43f3dbc-c7e6-4a73-a009-528c216a5467</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Customer</value>
      <webElementGuid>d6b52f0e-5e52-4772-b877-b2e5f6afe776</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/div[3]/div[1]/ul[@class=&quot;menusubnav&quot;]/li[2]/a[1]</value>
      <webElementGuid>fd2d191f-29c0-4f7a-bbf1-1ec20443ab4e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'New Customer')]</value>
      <webElementGuid>27832ace-d04f-497c-abcf-264363106b9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manager'])[1]/following::a[1]</value>
      <webElementGuid>02212225-628e-48a1-bc65-0222ceb9e92b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guru99 Bank'])[1]/following::a[2]</value>
      <webElementGuid>fb72fe8b-b3f5-4f17-8e7b-6d0ba639271f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Customer'])[1]/preceding::a[1]</value>
      <webElementGuid>5337b26a-8441-4e23-a915-babac72d20a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete Customer'])[1]/preceding::a[2]</value>
      <webElementGuid>f6913ba4-d123-4522-a957-193009e43abc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Customer']/parent::*</value>
      <webElementGuid>b4cd69a4-5122-4dfd-a890-e549f6ddf42c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'addcustomerpage.php')]</value>
      <webElementGuid>437d8c47-8848-446b-b997-d7ef033ad070</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[2]/a</value>
      <webElementGuid>ed2389be-2c59-4ffd-b519-36171d953696</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'addcustomerpage.php' and (text() = 'New Customer' or . = 'New Customer')]</value>
      <webElementGuid>2096c342-f79f-4ab7-80f0-44c0cb9ddda2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
