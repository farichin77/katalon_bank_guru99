<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_PIN Code must have 6 Digits</name>
   <tag></tag>
   <elementGuidId>77534cb3-a800-4ad9-a9f5-e19844e44be5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(10) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='PIN'])[1]/following::td[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>td >> internal:has-text=/^PIN Code must have 6 Digits$/</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>3e7cfb86-655c-4802-80e0-b26ce7ba117a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PIN Code must have 6 Digits</value>
      <webElementGuid>c83950d8-f5a6-4292-8454-cfdcdf6013c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/table[@class=&quot;layout&quot;]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[10]/td[2]</value>
      <webElementGuid>b7296946-6f2b-451e-a09f-a1a3c5dc30c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PIN'])[1]/following::td[1]</value>
      <webElementGuid>a8618844-462d-4550-a5ee-03b4b0363160</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State'])[1]/following::td[3]</value>
      <webElementGuid>3e97498a-1606-4973-866e-e8aa51ce68fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mobile Number'])[1]/preceding::td[1]</value>
      <webElementGuid>1c768587-ac68-433b-8f8c-6f079727dab6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[10]/td[2]</value>
      <webElementGuid>cdf0a2ff-ea6f-48bf-8704-0be4aa0708ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'PIN Code must have 6 Digits' or . = 'PIN Code must have 6 Digits')]</value>
      <webElementGuid>e69cde71-1dbe-4227-bf5a-f7809f6824d7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
