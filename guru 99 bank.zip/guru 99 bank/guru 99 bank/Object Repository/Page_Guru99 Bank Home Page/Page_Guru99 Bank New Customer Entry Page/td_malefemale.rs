<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_malefemale</name>
   <tag></tag>
   <elementGuidId>0c31f18b-d4f4-42fd-b90a-61ec5adf8888</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(5) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Gender'])[1]/following::td[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;male female&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>9bf0db24-8838-4bd7-ac52-016501b87cd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	male
	female
	</value>
      <webElementGuid>821c6b14-f409-4c1f-b838-23391d29b93f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;cb-customize-desktop chrome&quot;]/body[1]/table[@class=&quot;layout&quot;]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[5]/td[2]</value>
      <webElementGuid>3b4d552f-dcc7-401b-b921-a1357bb85235</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gender'])[1]/following::td[1]</value>
      <webElementGuid>02e6b3c6-1021-4a1b-a158-df0c2f72ee8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer Name'])[1]/following::td[3]</value>
      <webElementGuid>2ab180d3-f01e-4e14-bb35-f7967910ebd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Date of Birth'])[1]/preceding::td[1]</value>
      <webElementGuid>a4f1b0bd-cf77-4bb3-92be-03101205e2bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::td[3]</value>
      <webElementGuid>59c31b6a-5f4f-48c2-a909-629f494ee4a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='male']/parent::*</value>
      <webElementGuid>4f0639f4-f858-4c5b-b70c-90c4f22c2dc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[5]/td[2]</value>
      <webElementGuid>5444cf01-9095-4501-a26e-38daed2ed9df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '
	male
	female
	' or . = '
	male
	female
	')]</value>
      <webElementGuid>be67ec14-4840-48e7-bd01-10ccad69f88e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
